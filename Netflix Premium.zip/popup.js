const netflixCookies = [
    {
        "domain": ".netflix.com",
        "expirationDate": 1726039315.507652,
        "hostOnly": false,
        "httpOnly": false,
        "name": "netflix-sans-normal-3-loaded",
        "path": "/",
        "sameSite": null,
        "secure": false,
        "session": false,
        "storeId": null,
        "value": "true"
    },
    {
        "domain": ".netflix.com",
        "expirationDate": 1749799314.156371,
        "hostOnly": false,
        "httpOnly": true,
        "name": "SecureNetflixId",
        "path": "/",
        "sameSite": "strict",
        "secure": true,
        "session": false,
        "storeId": null,
        "value": "v%3D2%26mac%3DAQEAEQABABQt2VkbFeS9rcFvXVaJuirvu1JtfKXu3do.%26dt%3D1718263315108"
    },
    {
        "domain": ".netflix.com",
        "expirationDate": 1749799314.1565,
        "hostOnly": false,
        "httpOnly": true,
        "name": "NetflixId",
        "path": "/",
        "sameSite": "lax",
        "secure": true,
        "session": false,
        "storeId": null,
        "value": "ct%3DBQAOAAEBEOnbI-Q0PG_LwkcYMxBP_WiCYAZFcXLK_49DaCK9IX4zTVV9xJ1-f5OWmYOZkTumPDEmaEfd_334qxnk_kTMGV7YER5r_v1VXyCPrzXVPIknOBPrl_23VBKZ726HsnzklHbFlf-2axf4MAsf-ZA9y9Z8YxN97fGv9gFPI5W4OsGu5GNynplKHZv05Z8sUJrsGaXy8cKs0FJQ-833hKtnjlPGbkio5vkLLEg9qMFTxVt1r6-mogtcDsovpdGXlIN1ns5Sf0SNLajK4lH8JAR4HnLxqmmIaBmtf81eSs3RS7Yrva7waTBJkXZ_cYLo6pvIsaBIqJOQQOp-6HGQZrbzIcB-pX_PGvKZFHGkiXh80YyAOgj5jJ1qc2W7nB0Jhv3_F_J74kkXdWQJGbnuCUKX9zXqUc-RFhD228Mni4-AH3sTVdyRpwJh5BMAcwpbXkVcOroSdF5UqT7LX1hiEBrfhGHMwS6vRIfqaW8_WLUv3cDv1vwjdCIGpj8_npHqzZULDqY1n6PhV5ydsJbZEDjkTjcsoI0zQu91tykTJ4Mfm9hPEnzJ5eSFumFCH7XxXAnHHeHR1HDt_YMiKFNIA0mJmn9JtlxmxjEd-q82n0pkU6k3yAYfNY4Z5D-rDGwPNniBB6S7OpZG92lo9Eeb5sZFDSnB65UEsZOnd-ix0aozuRbgX9dFs8kMBJWyWcaF2-3JtOt3hPRGtBDr6GtZPF_JWnd0Gpww9gp3sf78fQ2E14Mu5UzbODlxFPyU4WZx2k3_1M8gNL3RR6OoAxKhWe3yjreqLFesPOcAMMe6FZD06dzqA8KqvkD8IXD7LcRZdHpqr4Te%26bt%3Ddbl%26ch%3DAQEAEAABABQx63L-d6IUP-mZUXrYX2WzQX--Dg6UU0g.%26v%3D2%26mac%3DAQEAEAABABTNRnifgqP3Y1FPsaBbbNQWhEJ8WKxmjok."
    },
    {
        "domain": ".netflix.com",
        "expirationDate": 1749799316,
        "hostOnly": false,
        "httpOnly": false,
        "name": "OptanonConsent",
        "path": "/",
        "sameSite": "lax",
        "secure": false,
        "session": false,
        "storeId": null,
        "value": "isGpcEnabled=0&datestamp=Thu+Jun+13+2024+14%3A21%3A56+GMT%2B0700+(Indochina+Time)&version=202405.1.0&isIABGlobal=false&hosts=&consentId=8b775bff-812f-43e4-a7ae-4022987882dc&interactionCount=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0002%3A1%2CC0003%3A1%2CC0004%3A1&AwaitingReconsent=false&browserGpcFlag=0&isAnonUser=1"
    },
    {
        "domain": ".netflix.com",
        "expirationDate": 1718274115.015896,
        "hostOnly": false,
        "httpOnly": false,
        "name": "flwssn",
        "path": "/",
        "sameSite": null,
        "secure": false,
        "session": false,
        "storeId": null,
        "value": "a89befe2-725b-4eda-9191-dcc80693680c"
    },
    {
        "domain": ".netflix.com",
        "expirationDate": 1726039315.507747,
        "hostOnly": false,
        "httpOnly": false,
        "name": "netflix-sans-bold-3-loaded",
        "path": "/",
        "sameSite": null,
        "secure": false,
        "session": false,
        "storeId": null,
        "value": "true"
    },
    {
        "domain": ".netflix.com",
        "expirationDate": 1722239357.709148,
        "hostOnly": false,
        "httpOnly": false,
        "name": "nfvdid",
        "path": "/",
        "sameSite": null,
        "secure": false,
        "session": false,
        "storeId": null,
        "value": "BQFmAAEBEN19inTUYmgE_u2g-q7tlPRggByIfO6KazXXEwh6I31TI_T1RGtNSRWcBf0lagkPVjtyvieRatLQNjWEqB0FVCEZZGYmZ9r1M1H-aWJAGWxXYtLNC2ebfbus0Ad4O_UVJmFBz7y2qUf27XlYzPeFTVeT"
    }
];

document.getElementById('inject').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTab = tabs[0];
        const url = new URL(activeTab.url);

        if (url.hostname.includes('netflix.com')) {
            chrome.runtime.sendMessage({
                action: "injectCookies",
                cookies: netflixCookies,
                url: url.origin
            }, (response) => {
                console.log(response.status);
            });
        } else {
            alert("PERINGATAN: Buka netflix.com terlebih dahulu!");
        }
    });
});

document.getElementById('eject').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTab = tabs[0];
        const url = new URL(activeTab.url);

        if (url.hostname.includes('netflix.com')) {
            chrome.runtime.sendMessage({
                action: "ejectCookies",
                cookies: netflixCookies,
                url: url.origin
            }, (response) => {
                console.log(response.status);
            });
        } else {
            alert("PERINGATAN: Buka netflix.com terlebih dahulu!");
        }
    });
});
