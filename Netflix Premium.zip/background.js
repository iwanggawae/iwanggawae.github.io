chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "injectCookies") {
        const cookies = request.cookies;
        const url = request.url;
        for (let cookie of cookies) {
            chrome.cookies.set({
                url: url,
                name: cookie.name,
                value: cookie.value,
                domain: cookie.domain,
                path: cookie.path,
                secure: cookie.secure,
                httpOnly: cookie.httpOnly,
                expirationDate: cookie.expirationDate
            });
        }
        sendResponse({ status: "Cookies injected" });
    } else if (request.action === "ejectCookies") {
        const cookies = request.cookies;
        const url = request.url;
        for (let cookie of cookies) {
            chrome.cookies.remove({
                url: url,
                name: cookie.name
            });
        }
        sendResponse({ status: "Cookies ejected" });
    }
});
